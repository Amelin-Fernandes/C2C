﻿namespace ShapeLib
{
    public class Paint
    {
        public abstract int CalculateArea();
        public abstract string FillColor(string color);
    }
}