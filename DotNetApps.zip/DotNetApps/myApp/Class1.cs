﻿namespace myApp;

public class Class1
{

}
